

self.addEventListener('fetch', (event) => {

  if (event.request.method === 'GET') {
    // fetch dynamic files the first time and return the second time from the cache
    event.respondWith((async () => {
      const response = await caches.match(event.request)

      if (response) return response;

      const result = await fetch(event.request)
      const cache = await caches.open('dynamic_files')

	  try {
		  tryResults=result.clone();
		  var res = await tryResults.json();
		  console.log(event.request.url, "no cache")
	  } catch (error) {
		  //console.error(error);
		  console.log(event.request.url, "cache")
		  cache.put(event.request.url, result.clone())
	  }
      return result
    })())
  }
})